package com.hand.filmmgt.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hand.filmmgt.model.Language;

public interface LanguageRepository extends JpaRepository<Language,Long>{

}
