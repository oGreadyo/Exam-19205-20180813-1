$(document).ready(function(){
	$("#loginpage").animate({top:'20%'},"slow");
});
